﻿using System.ComponentModel.DataAnnotations;

namespace TPLOCAL1.Models
{
    public class FormModel
    {
        [Required]
        public string Nom { get; set; }

        [Required]
        public string Prenom { get; set; } 
        [Required]
        public string Sexe { get; set; }

        [Required]
        public string Adresse { get; set; } 

        [Required]
        public string CodePostal { get; set; }

        [Required]
        public string Ville { get; set; }

        [Required]
        public string Email { get; set; }

        [Required]
        public DateTime Date { get; set; }

        [Required]
        public string Formation { get; set; }

        public string? AvisCobol { get; set; }

        public string? AvisC { get; set; }
    }
}
